#           Very Poorly Coded Raycasting Engine (VPCRE)
#           by Quinn James








w = 800             #window resolution
h = 600
FPS = 60            #fps of the window

#begin code
import pygame, sys, random, math, time, itertools
from pygame.locals import *

# set up pygame
pygame.mixer.pre_init(44100, -16, 2, 2048)
pygame.mixer.init()
pygame.init()
mainClock = pygame.time.Clock()
DISPLAYSURF = pygame.display.set_mode((w, h), 0, 32)
pygame.display.set_caption('Void')
BLACK = (0, 0, 0)
WHITE = (200, 200, 200)
WHITE2 = (150, 150, 150)
RED = (200, 0, 0)
RED2 = (150, 0, 0)
GREEN = (0, 200, 0)
GREEN2 = (0, 150, 0)
BLUE = (0, 0, 200)
BLUE2 = (0, 0, 150)
zBuffer = [' ',] * (w+1)
currentMap = 1
cooldown = 0
DISPLAYSURF.fill((0,0,0))
font = pygame.font.SysFont("simhei", 20)
text = font.render("Loading", True, (random.sample((60,60,60,60,60,60,60,60,60,60,60,60,0),1)[0], 10, 10))
DISPLAYSURF.blit(text,(40,100))
pygame.display.update()
        
#main variables
texWidth = 48
texHeight = 48
dw = 0
da = 0
ds = 0
dd = 0
cx = 0      #column on screen
moveSpeed = 0.08
rotSpeed = 0.06
spawnX = 0.0
spawnY = 0.0
demo = 1
tutorial = 1
levelLoad = 0.5
tick = 0


#textures and sound
texture = [' ',] * 20
texture[1] = pygame.image.load('1.png')
texture[2] = pygame.image.load('2.png')
texture[3] = pygame.image.load('3.png')
texture[4] = pygame.image.load('4.png')
texture[5] = pygame.image.load('5.png')
texture[6] = pygame.image.load('6.png')
texture[7] = pygame.image.load('7.png')
texture[8] = pygame.image.load('8.png')
texture[10] = pygame.image.load('10.png')
texture[11] = pygame.image.load('11.png')
texture[12] = pygame.image.load('12.png')
texture[13] = pygame.image.load('13.png')
texture[15] = pygame.image.load('15.png')
texture[18] = pygame.image.load('15-2.png')
texture[16] = pygame.image.load('16.png')
texture[17] = pygame.image.load('17.png')
healthg = [' ',] * 20
healthg[0] = pygame.image.load('h0.png')
healthg[1] = pygame.image.load('h1.png')
healthg[2] = pygame.image.load('h2.png')
healthg[3] = pygame.image.load('h3.png')
healthg[4] = pygame.image.load('h4.png')
healthg[5] = pygame.image.load('h5.png')
healthg[6] = pygame.image.load('h6.png')
healthg[7] = pygame.image.load('h7.png')
healthg[8] = pygame.image.load('h8.png')
healthg[9] = pygame.image.load('h9.png')
healthg[10] = pygame.image.load('h10.png')
z1 = pygame.mixer.Sound('z1.ogg')
z2 = pygame.mixer.Sound('z2.ogg')
z3 = pygame.mixer.Sound('z3.ogg')
z4 = pygame.mixer.Sound('z4.ogg')
c1 = pygame.mixer.Sound('c1.ogg')
c2 = pygame.mixer.Sound('c2.ogg')
p1 = pygame.mixer.Sound('p1.ogg')
l1 = pygame.mixer.Sound('l1.ogg')
b0 = pygame.mixer.Sound('b0.ogg')
b1 = pygame.mixer.Sound('b1.ogg')
b2 = pygame.mixer.Sound('b2.ogg')
b3 = pygame.mixer.Sound('b3.ogg')
b4 = pygame.mixer.Sound('b4.ogg')
b5 = pygame.mixer.Sound('b5.ogg')
b6 = pygame.mixer.Sound('b6.ogg')

# main program loop
while True:

    health = 10

    if currentMap == 1:     #title screen
        map = [
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,2,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,2,1],
            [1,0,0,0,0,0,2,2,2,2,2,2,2,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,3,3,0,0,0,0,0,4,4,0,0,0,1],
            [1,3,3,0,0,0,0,0,4,4,0,0,0,1],
            [1,0,0,0,0,0,0,0,4,4,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,5,5,5,0,0,0,0,0,0,0,1],
            [1,0,0,5,5,5,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,6,6,6,6,1],
            [1,0,0,0,0,0,0,0,0,6,6,6,6,1],
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1]]

        
        posX = 1.1
        posY = 1.1
        dirX = 0.7373
        dirY = 0.6754
        planeX = 0.4458
        planeY = -0.4866
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        spriteNum = 0
        b0.play()
        
    if currentMap == 2:
        map = [
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
            [8,8,8,8,6,6,6,6,5,5,5,5,2,2,2,2,7,7,7,7],
            [8,-1,-1,8,6,-5,-5,6,5,-3,-3,5,2,-4,-4,2,7,-2,-2,7],
            [8,-1,-1,8,6,-5,-5,6,5,-3,-3,5,2,-4,-4,2,7,-2,-2,7],
            [1,0,0,0,-5,-5,-5,-5,-3,-3,-3,-3,-4,-4,-4,-4,-6,-6,-6,1],
            [1,0,0,0,-5,-5,-5,-5,-3,-3,-3,-3,-4,-4,-4,-4,-6,-6,-6,1],
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]]
        posX = 3.5
        posY = 2.0
        dirX = -1.0
        dirY = 0.0
        planeX = 0.0
        planeY = 0.66
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        sprite[1] = [3.0,6.0,texture[15],10,0,0,15]
        sprite[2] = [3.0,10.0,texture[13],10,0,0,13]
        sprite[3] = [3.0,14.0,texture[16],10,0,0,16]
        spriteNum = 3
        tutorial = 1
        b1.play()

    if currentMap == 3:
        map = [
            [1,1,1,3,3,3,3,3,3,4,3,3,3,3,3,1,1,1],
            [1,0,0,3,0,0,0,0,0,0,0,0,0,0,4,0,0,1],
            [8,8,8,3,0,0,0,0,0,0,0,0,0,0,4,7,7,7],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,8,8,3,0,0,0,0,0,0,0,0,0,0,3,7,7,7],
            [1,0,0,5,0,0,0,0,0,0,0,0,0,0,4,0,0,1],
            [1,1,1,5,5,5,5,5,3,3,3,3,4,3,3,1,1,1]]
        posX = 4.0
        posY = 2.0
        dirX = -1.0
        dirY = 0.0
        planeX = 0.0
        planeY = 0.66
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        sprite[1] = [4.5,9.0,texture[15],10,0,0,15]
        sprite[2] = [1.5,4.5,texture[10],100,0,0,10]
        sprite[3] = [7.5,4.5,texture[10],100,0,0,10]
        sprite[4] = [1.5,13.5,texture[10],100,0,0,10]
        sprite[5] = [7.5,13.5,texture[10],100,0,0,10]
        spriteNum = 5
        b2.play()

    if currentMap == 4:
        map = [
            [1,1,1,3,3,3,3,3,3,4,3,3,3,3,3,1,1,1],
            [1,0,0,3,0,0,0,0,0,0,0,0,0,0,4,0,0,1],
            [8,8,8,3,0,0,0,0,0,0,0,0,0,0,4,7,7,7],
            [8,-1,-1,0,0,6,0,0,0,0,6,0,0,0,0,-2,-2,7],
            [8,-1,-1,0,0,6,0,0,0,0,6,0,0,0,0,-2,-2,7],
            [8,-1,-1,0,0,6,0,0,0,0,6,0,0,0,0,-2,-2,7],
            [8,8,8,3,0,0,0,0,0,0,0,0,0,0,3,7,7,7],
            [1,0,0,5,0,0,0,0,0,0,0,0,0,0,4,0,0,1],
            [1,1,1,5,5,5,5,5,3,3,3,3,4,3,3,1,1,1]]
        posX = 4.0
        posY = 2.0
        dirX = -1.0
        dirY = 0.0
        planeX = 0.0
        planeY = 0.66
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        sprite[1] = [4.5,9.0,texture[15],10,0,0,15]
        sprite[2] = [1.5,4.5,texture[10],100,0,0,10]
        sprite[3] = [7.5,4.5,texture[10],100,0,0,10]
        sprite[4] = [1.5,13.5,texture[10],100,0,0,10]
        sprite[5] = [7.5,13.5,texture[10],100,0,0,10]
        spriteNum = 5
        b3.play()

    if currentMap == 5:
        map = [
            [1, 8, 8,6,6,6,6,6,6,6,6,6,6,6,6,1,1,1],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,6,0,0,1],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,6,7,7,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,6,7,7,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,6,0,0,1],
            [8, 8, 8,8,6,6,6,6,6,6,6,6,6,6,6,1,1,1]]
        posX = 4.0
        posY = 2.0
        dirX = -1.0
        dirY = 0.0
        planeX = 0.0
        planeY = 0.66
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        sprite[1] = [6.5,11.0,texture[16],10,0,0,16]
        spriteNum = 1
        b4.play()

    if currentMap == 6:
        map = [
            [1, 8, 8,6,6,6,6,6,6,6,6,6,6,6,6,1,1,1],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,6,0,0,1],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,6,7,7,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,6,7,7,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,6,0,0,1],
            [8, 8, 8,8,6,6,6,6,6,6,6,6,6,6,6,1,1,1]]
        posX = 4.0
        posY = 2.0
        dirX = -1.0
        dirY = 0.0
        planeX = 0.0
        planeY = 0.66
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        sprite[1] = [3.5,8.0,texture[16],10,0,0,16]
        sprite[2] = [6.5,11.0,texture[15],10,0,0,15]
        sprite[3] = [4.5,9.0,texture[13],10,0,0,13]
        spriteNum = 3
        b5.play()

    if currentMap == 7:
        map = [
            [1, 8, 8,1,1,2,1,1,1,1,2,1,1,1,1,1,2,1],
            [8,-1,-1,0,0,0,1,0,0,2,0,0,0,0,1,0,0,1],
            [8,-1,-1,0,0,0,1,0,2,1,0,1,2,0,1,7,7,7],
            [8,-1,-1,8,1,0,1,0,2,0,0,0,1,0,0,-2,-2,7],
            [8,-1,-1,8,1,0,1,0,2,1,1,0,2,0,0,-2,-2,7],
            [8,-1,-1,8,2,0,0,0,1,0,0,0,1,0,0,-2,-2,7],
            [8,-1,-1,8,1,0,2,1,2,0,1,0,1,2,2,7,7,7],
            [8,-1,-1,8,2,0,0,0,0,0,1,0,0,0,2,0,0,1],
            [8, 8, 8,8,1,2,2,1,2,1,1,2,2,2,1,2,1,1]]
        posX = 4.0
        posY = 2.0
        dirX = -1.0
        dirY = 0.0
        planeX = 0.0
        planeY = 0.66
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        sprite[1] = [3.5,8.0,texture[16],10,0,0,16]
        sprite[2] = [6.5,11.0,texture[13],10,0,0,13]
        spriteNum = 2
        b6.play()

    if currentMap == 8:
        map = [
            [1, 8, 8,6,6,6,6,6,6,6,6,6,6,6,6,1,1,1],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,6,0,0,1],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,6,7,7,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,6,7,7,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,6,0,0,1],
            [8, 8, 8,8,6,6,6,6,6,6,6,6,6,6,6,1,1,1]]
        posX = 4.0
        posY = 2.0
        dirX = -1.0
        dirY = 0.0
        planeX = 0.0
        planeY = 0.66
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        sprite[1] = [7.5,9.0,texture[16],10,0,0,16]
        sprite[2] = [4.5,9.0,texture[16],10,0,0,16]
        sprite[3] = [2.5,9.0,texture[16],10,0,0,16]
        spriteNum = 3
        b2.play()

    if currentMap == 9:
        map = [
    [8,8,8,8,8,5,3,3,3,4,3,3,3,3,3,4,3,3,3,3,3,3,3,3,3,4,3,5,4,3,3,3,3,3,4,3,3,3,3,3,3,],
    [8,-1,-1,-1,0,0,0,0,0,0,0,0,3,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,4,],
    [8,-1,-1,-1,0,3,3,3,3,5,3,0,3,4,3,0,3,0,3,0,3,3,3,0,4,3,3,3,3,0,3,0,4,3,3,0,3,0,5,0,4,],
    [8,-1,-1,-1,0,0,0,0,3,0,0,0,3,0,0,0,3,0,0,0,4,0,3,0,0,0,4,0,0,0,3,0,0,0,0,0,3,0,4,0,4,],
    [8,-1,-1,-1,0,0,3,3,3,0,3,3,3,3,3,0,3,4,3,5,3,0,3,3,3,0,3,0,3,0,4,3,3,3,3,0,3,3,3,0,3,],
    [8,-1,-1,-1,0,0,3,0,4,0,5,0,0,0,0,0,0,0,0,0,3,0,3,0,0,0,3,0,3,0,0,0,0,0,3,0,0,0,0,0,4,],
    [8,0,0,0,0,3,3,0,3,0,3,0,3,4,3,3,3,3,4,5,3,0,3,0,4,3,3,0,4,3,4,0,4,3,3,3,3,3,3,0,3,],
    [3,0,0,0,5,0,0,0,0,0,4,0,0,0,3,0,0,0,0,0,3,0,3,0,0,0,0,0,3,0,3,0,3,0,0,0,0,0,0,0,3,],
    [3,0,3,4,3,3,3,5,3,0,3,4,3,0,3,0,3,3,3,0,4,0,3,0,3,3,3,4,5,0,3,0,3,0,4,3,3,4,3,3,3,],
    [3,0,0,0,0,0,0,0,3,0,3,0,0,0,5,0,3,0,0,0,0,0,3,0,0,0,0,0,3,0,3,0,3,0,0,0,3,0,0,0,3,],
    [3,0,3,5,3,3,3,0,3,3,3,0,3,3,5,0,3,3,3,3,3,3,3,5,3,3,3,0,3,0,3,0,3,5,3,0,3,0,3,0,3,],
    [3,0,0,0,5,0,3,0,0,0,0,0,0,0,3,0,0,0,3,0,0,0,0,0,3,0,0,0,5,0,5,0,0,0,0,0,3,0,3,0,3,],
    [5,3,3,0,5,0,3,5,5,5,3,5,3,3,5,3,3,0,3,0,5,3,3,3,3,0,5,3,3,0,3,3,3,0,5,3,3,3,3,0,3,],
    [3,0,0,0,5,0,0,0,3,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,3,],
    [3,0,3,3,5,0,3,0,3,0,3,3,3,3,3,0,3,5,3,3,3,0,3,3,3,3,3,3,5,0,3,3,3,3,3,0,3,3,3,0,3,],
    [3,0,5,0,0,0,3,0,3,0,0,0,0,0,3,0,3,0,0,0,3,0,3,0,0,0,3,0,0,0,0,0,0,0,0,0,3,0,0,0,3,],
    [3,0,3,0,5,3,3,3,3,3,3,3,3,0,5,3,3,0,3,0,3,3,3,0,3,0,3,3,3,3,3,3,3,3,3,3,3,0,3,3,3,],
    [3,0,0,0,3,0,0,0,3,0,0,0,0,0,3,0,0,0,4,0,3,0,0,0,3,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,3,],
    [3,3,3,0,3,0,3,0,4,0,3,0,3,3,3,0,3,3,3,0,3,0,4,3,3,3,3,3,3,3,4,0,3,0,3,3,3,3,3,0,4,],
    [3,0,3,0,3,0,3,0,0,0,3,0,4,0,0,0,0,0,3,0,3,0,0,0,0,0,0,0,0,0,3,0,3,0,4,0,0,0,3,0,3,],
    [3,0,4,0,3,0,3,0,4,3,4,4,3,0,3,3,3,3,3,0,3,3,3,4,3,3,3,3,3,0,3,0,3,3,4,0,3,0,3,3,3,],
    [3,0,0,0,3,0,3,0,4,0,0,0,0,0,3,0,3,0,0,0,0,0,3,0,0,0,0,0,3,0,3,0,0,0,3,0,4,0,0,0,3,],
    [3,0,3,3,3,0,4,3,3,0,3,3,0,4,3,0,3,0,3,4,3,0,3,4,3,4,4,0,3,0,3,3,3,0,3,0,3,3,3,0,3,],
    [4,0,0,0,3,0,0,0,0,0,3,0,0,0,0,0,3,0,3,0,0,0,0,0,0,0,0,0,3,0,0,0,3,0,3,0,0,0,3,0,3,],
    [4,3,3,0,3,3,3,3,3,4,3,3,3,0,3,0,3,0,3,4,3,3,3,0,3,3,4,3,3,3,3,0,4,0,3,3,3,0,4,0,3,],
    [3,0,4,0,0,0,0,0,0,0,0,0,0,0,3,0,4,0,4,0,0,0,3,0,3,0,0,0,0,0,0,0,3,0,0,0,0,0,3,0,3,],
    [3,0,3,3,3,4,3,3,3,3,3,3,3,0,4,3,3,0,3,0,4,0,3,0,4,0,3,3,3,4,3,3,3,4,4,4,3,3,4,0,4,],
    [3,0,0,0,0,0,0,0,4,0,0,0,4,0,4,0,0,0,3,0,4,0,3,0,3,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,4,],
    [3,0,3,4,3,3,3,0,4,0,4,0,3,0,3,0,3,3,3,0,3,0,3,4,3,0,3,3,3,3,3,3,3,3,3,0,3,0,3,0,3,],
    [3,0,0,0,3,0,3,0,0,0,3,0,3,0,3,0,4,0,0,0,3,0,0,0,0,0,3,0,0,0,4,0,0,0,3,0,3,0,4,0,4,],
    [3,3,3,0,3,0,3,0,4,3,3,3,3,0,3,0,3,0,3,4,3,3,3,3,3,3,4,0,3,0,3,0,3,0,3,0,3,0,4,0,3,],
    [3,0,0,0,3,0,0,0,3,0,0,0,0,0,3,0,4,0,3,0,0,0,0,0,0,0,0,0,3,0,0,0,3,0,3,0,3,0,4,0,3,],
    [3,0,3,4,4,0,3,3,3,0,3,3,3,3,4,0,3,0,4,4,3,0,3,3,3,3,3,3,3,3,3,3,3,0,3,3,3,0,3,0,3,],
    [3,0,3,0,0,0,5,0,0,0,5,0,0,0,0,0,5,0,0,0,5,0,0,0,0,0,0,0,3,0,0,0,3,0,0,0,0,0,3,0,3,],
    [3,0,5,5,5,3,3,0,3,3,3,0,5,3,3,3,3,3,5,0,3,3,3,3,5,5,3,3,3,3,5,0,3,3,3,5,3,3,5,0,5,],
    [5,0,0,0,0,0,3,0,4,0,3,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,3,0,0,0,3,0,4,0,0,0,5,0,3,0,3,],
    [3,0,4,3,5,0,3,0,3,0,4,3,3,4,4,0,4,0,5,3,3,3,4,5,4,0,3,3,3,4,5,0,3,0,3,0,3,0,4,0,3,],
    [5,0,0,0,3,0,0,0,3,0,0,0,0,0,4,0,3,0,3,0,0,0,0,0,3,0,5,0,0,0,3,0,4,0,3,0,0,0,0,0,7,],
    [3,3,3,0,5,3,4,3,3,3,3,0,3,0,4,0,5,3,3,0,3,3,4,0,3,0,3,0,5,0,3,0,4,0,3,3,3,3,-2,-2,7,],
    [3,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,4,0,0,0,3,0,0,0,0,0,-2,-2,7,],
    [3,5,3,4,3,3,3,3,5,4,3,3,3,3,3,4,3,5,3,3,4,3,3,3,5,3,3,3,3,5,3,4,4,4,3,5,4,3,7,7,7,]]
        posX = 4.0
        posY = 2.0
        dirX = -1.0
        dirY = 0.0
        planeX = 0.0
        planeY = 0.66
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        spriteNum = 0
        b6.play()

    if currentMap == 10:
        map = [
            [1, 8, 8,6,6,6,6,6,6,6,6,6,6,6,6,1,1,1],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,6,0,0,1],
            [8,-1,-1,0,0,0,0,0,0,0,0,0,0,0,6,7,7,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,0,-2,-2,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,6,7,7,7],
            [8,-1,-1,8,6,0,0,0,0,0,0,0,0,0,6,0,0,1],
            [8, 8, 8,8,6,6,6,6,6,6,6,6,6,6,6,1,1,1]]
        posX = 4.0
        posY = 2.0
        dirX = -1.0
        dirY = 0.0
        planeX = 0.0
        planeY = 0.66
        sprite = [[0,0,texture[10],-1,0,0,10],] * 7
        sprite[1] = [3.5,8.0,texture[15],10,0,0,15]
        sprite[2] = [6.5,11.0,texture[15],10,0,0,15]
        sprite[3] = [7.5,9.0,texture[16],10,0,0,16]
        sprite[4] = [4.5,9.0,texture[16],10,0,0,16]
        sprite[5] = [2.5,9.0,texture[16],10,0,0,16]
        sprite[6] = [8.5,12.0,texture[15],10,0,0,15]
        spriteNum = 3
        b6.play()


            

    mw = len(map[1])
    mh = len(map)
    breakL = 1

    while breakL == 1:
        #movement
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                orderSprite = 0
                while orderSprite <= spriteNum:
                    if abs(sprite[orderSprite][0] - posX) < 2 and abs(sprite[orderSprite][1] - posY) < 2 and sprite[orderSprite][4] == 1 and sprite[orderSprite][5] < 1:
                        sprite[orderSprite][3] = sprite[orderSprite][3] - 1
                        sprite[orderSprite][5] = 40
                        if random.randint(1,2) == 1 and sprite[orderSprite][3] > 0:     #player punching sprite system
                            z2.play()
                        elif sprite[orderSprite][3] <= 0:
                            z4.play()
                        else:
                            z3.play()
                    orderSprite = orderSprite + 1
                    
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    dw = 1
                if event.key == pygame.K_a:
                    da = 1
                if event.key == pygame.K_s:
                    ds = 1
                if event.key == pygame.K_d:
                    dd = 1

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_w:
                    dw = 0
                if event.key == pygame.K_a:
                    da = 0
                if event.key == pygame.K_s:
                    ds = 0
                if event.key == pygame.K_d:
                    dd = 0

            if event.type == QUIT:
                pygame.quit()
                sys.exit()    

        if dw == 1 and demo == 0:
            if map[int(posX + dirX * moveSpeed)][int(posY)] <= 0:
                posX = posX + dirX * moveSpeed
            if map[int(posX)][int(posY + dirY * moveSpeed)] <= 0:
                posY = posY + dirY * moveSpeed
        if ds == 1 and demo == 0:
            if map[int(posX - dirX * moveSpeed)][int(posY)] <= 0:
                posX = posX - dirX * moveSpeed
            if map[int(posX)][int(posY - dirY * moveSpeed)] <= 0:   #forward and backward
                posY = posY - dirY * moveSpeed
        if da == 1 and demo == 0:
            oldDirX = dirX
            dirX = dirX * math.cos(rotSpeed) - dirY * math.sin(rotSpeed)
            dirY = oldDirX * math.sin(rotSpeed) + dirY * math.cos(rotSpeed)
            oldPlaneX = planeX
            planeX = planeX * math.cos(rotSpeed) - planeY * math.sin(rotSpeed)
            planeY = oldPlaneX * math.sin(rotSpeed) + planeY * math.cos(rotSpeed)
        if dd == 1 and demo == 0:
            oldDirX = dirX
            dirX = dirX * math.cos(-rotSpeed) - dirY * math.sin(-rotSpeed)
            dirY = oldDirX * math.sin(-rotSpeed) + dirY * math.cos(-rotSpeed)
            oldPlaneX = planeX
            planeX = planeX * math.cos(-rotSpeed) - planeY * math.sin(-rotSpeed)
            planeY = oldPlaneX * math.sin(-rotSpeed) + planeY * math.cos(-rotSpeed) #rotate direction and camera plane using trig

        #rendering loop
        DISPLAYSURF.fill((0,0,0))
        cx = 0
        while cx <= w:
            #set starting ray location
            cameraX = 2.0 * cx / w - 1 #x coor in camera space
            rayPosX = posX
            rayPosY = posY
            rayDirX = dirX + planeX * cameraX
            rayDirY = dirY + planeY * cameraX
            if rayDirX == 0:
                rayDirX = 0.0001
            if rayDirY == 0:
                rayDirY = 0.0001
            mapX = int(rayPosX)
            mapY = int(rayPosY) #coord of box on map
            deltaDistX = math.sqrt(1 + (rayDirY * rayDirY) / (rayDirX * rayDirX))
            deltaDistY = math.sqrt(1 + (rayDirX * rayDirX) / (rayDirY * rayDirY))   #calculates distnace between X and Y lines on grid
            hit = 0     #1 when wall is hit

            #calculate steps and sidedistance
            if rayDirX < 0:
                stepX = -1
                sideDistX = (rayPosX - mapX) * deltaDistX
            else:
                stepX = 1
                sideDistX = (mapX + 1.0 - rayPosX) * deltaDistX
            if rayDirY < 0:
                stepY = -1
                sideDistY = (rayPosY - mapY) * deltaDistY
            else:
                stepY = 1
                sideDistY = (mapY + 1.0 - rayPosY) * deltaDistY

            #raycast over grid using deltas
            while hit == 0:
                if sideDistX < sideDistY:           #add x detla is x gridline closer, otherwise add y delta
                    sideDistX = sideDistX + deltaDistX
                    mapX = mapX + stepX
                    side = 0
                else:
                    sideDistY = sideDistY + deltaDistY
                    mapY = mapY + stepY
                    side = 1
                if map[mapX][mapY] > 0:
                    hit = 1
            #calculate wall size and display
            if side == 0:
                perpWallDist = (mapX - rayPosX + (1 - stepX) / 2) / rayDirX
            else:
                perpWallDist = (mapY - rayPosY + (1 - stepY) / 2) / rayDirY     #display wall size relative to plane perpendicular of player, depending on x or y side hit
            if perpWallDist == 0:
                perpWallDist = 0.0001
            lineHeight = int(h / perpWallDist)  #overall height of line
            if lineHeight > h:
                lineHeight = h
            drawStart = (-lineHeight / 2) + (h / 2)
            drawEnd = (lineHeight / 2) + (h / 2)    #y coordinates of line start and end, offset to center
            if drawStart < 0:
                drawStart = 0
            if drawEnd >= h:
                drawEnd = h - 1     #don't allow close lines to extend infinitely

            #sprite distance tuple
            zBuffer[cx] = perpWallDist

            #render columns
            texNum = map[mapX][mapY]
            if side == 0:
                wallX = rayPosY + perpWallDist * rayDirY
            else:
                wallX = rayPosX + perpWallDist * rayDirX
            wallX = wallX - math.floor(wallX)   #determine where ray hit on wall
            texX = int(wallX * texWidth)
            if side == 0 and rayDirX > 0:
                texX = texWidth - texX - 1
            if side == 1 and rayDirY < 0:
                texX = texWidth - texX - 1      #determine x coord on texture
            imageSlice = texture[texNum].subsurface((texX, 0, 1, texHeight))
            scaledSlice = pygame.transform.scale(imageSlice,(1,lineHeight))
            DISPLAYSURF.blit(scaledSlice, (cx, drawStart))

            #increment column
            cx = cx + 1

            if demo == 1:
                time.sleep(0.1)
                font = pygame.font.SysFont("simhei", 72)
                text = font.render("Void", True, (random.sample((100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,0),1)[0], 20, 20))
                DISPLAYSURF.blit(text,(30,30))
                font = pygame.font.SysFont("simhei", 20)
                text = font.render("by Quinn James", True, (random.sample((60,60,60,60,60,60,60,60,60,60,60,60,0),1)[0], 10, 10))
                DISPLAYSURF.blit(text,(40,100))
                pygame.display.update()
                cx = random.randint(0,799)

                for event in pygame.event.get():
                    if event.type == MOUSEBUTTONDOWN:
                        b0.stop()
                        DISPLAYSURF.fill(BLACK)
                        font = pygame.font.SysFont("simhei", 72)
                        text = font.render("Tutorial", True, (100, 20, 20))
                        DISPLAYSURF.blit(text,(30,30))
                        font = pygame.font.SysFont("simhei", 20)
                        text = font.render("Loading...", True, (60, 10, 10))
                        DISPLAYSURF.blit(text,(40,100))
                        pygame.display.update()
                        time.sleep(levelLoad)
                        currentMap = 2
                        breakL = 2
                        demo = 0
                    if event.type == QUIT:
                        pygame.quit()
                        sys.exit()    
                
        #outside render loop

        #draw sprites
        orderSprite = 0
        while orderSprite <= spriteNum:
            spriteX = (sprite[orderSprite][0] - posX)
            spriteY = (sprite[orderSprite][1] - posY) #pos relative to camera
            intDet = 1.0 / (planeX * dirY - dirX * planeY)
            transformX = intDet * (dirY * spriteX - dirX * spriteY)     #distance across screen
            transformY = intDet * (-planeY * spriteX + planeX * spriteY)    #distnace back from screen
            spriteScreenX = int((w / 2) * (1 + transformX / transformY))
            spriteHeight = abs(int(h / transformY))
            drawStartY = -spriteHeight / 2 + h / 2
            if drawStartY < 0:
                drawStartY = 0
            spriteWidth = abs(int(h / transformY))
            drawStartX = -spriteWidth / 2 + spriteScreenX
            if sprite[orderSprite][3] > 0 and drawStartX >= 0 and drawStartX < w and transformY < zBuffer[drawStartX] and transformY > 0:
                if spriteWidth > w:
                    spriteWidth = w
                if spriteHeight > h:
                    spriteHeight = h
                currentSprite = pygame.transform.scale(sprite[orderSprite][2],(spriteWidth,spriteHeight))
                if sprite[orderSprite][5] > 1 and sprite[orderSprite][6] == 15:
                    currentSprite = pygame.transform.scale(texture[18],(spriteWidth,spriteHeight))
                DISPLAYSURF.blit(currentSprite,(drawStartX,drawStartY))
                sprite[orderSprite][4] = 1
            else:
                sprite[orderSprite][4] = 0
            orderSprite = orderSprite + 1

        #ai
        orderSprite = 0
        if tutorial != 1:
            while orderSprite <= spriteNum:
                sprite[orderSprite][5] = sprite[orderSprite][5] - 1
                if sprite[orderSprite][6] >= 15 and sprite[orderSprite][0] < posX and abs(sprite[orderSprite][0] - posX) < 3 and abs(sprite[orderSprite][1] - posY) < 3 and map[int(sprite[orderSprite][0])][int(sprite[orderSprite][1])] < 1:
                    sprite[orderSprite][0] = sprite[orderSprite][0] + 0.01
                elif sprite[orderSprite][6] >= 15 and sprite[orderSprite][0] > posX and abs(sprite[orderSprite][0] - posX) < 3 and abs(sprite[orderSprite][1] - posY) < 3 and map[int(sprite[orderSprite][0])][int(sprite[orderSprite][1])] < 1:
                    sprite[orderSprite][0] = sprite[orderSprite][0] - 0.01
                if sprite[orderSprite][6] >= 15 and sprite[orderSprite][1] < posY and abs(sprite[orderSprite][1] - posY) < 3 and abs(sprite[orderSprite][0] - posX) < 3 and map[int(sprite[orderSprite][0])][int(sprite[orderSprite][1])] < 1:
                    sprite[orderSprite][1] = sprite[orderSprite][1] + 0.01
                elif sprite[orderSprite][6] >= 15 and sprite[orderSprite][1] > posY and abs(sprite[orderSprite][1] - posY) < 3 and abs(sprite[orderSprite][0] - posX) < 3 and map[int(sprite[orderSprite][0])][int(sprite[orderSprite][1])] < 1:
                    sprite[orderSprite][1] = sprite[orderSprite][1] - 0.01
                if sprite[orderSprite][6] == 15 and sprite[orderSprite][3] > 0 and abs(sprite[orderSprite][0] - posX) < 0.5 and abs(sprite[orderSprite][1] - posY) < 0.5 and cooldown < 1:
                    health = health - 1
                    cooldown = 60
                    DISPLAYSURF.fill((255,0,0,0.5))
                    p1.play()
                if sprite[orderSprite][6] == 16 and sprite[orderSprite][3] > 0 and abs(sprite[orderSprite][0] - posX) < 1 and abs(sprite[orderSprite][1] - posY) < 1 and sprite[orderSprite][5] <= 0:
                    sprite[orderSprite][5] = 50
                    sprite[orderSprite][6] = 19
                    c1.play()
                if sprite[orderSprite][6] == 19 and sprite[orderSprite][5] <= 0:
                    c2.play()
                    sprite[orderSprite][3] = 0
                    sprite[orderSprite][6] = 15
                    if cooldown <= 0 and abs(sprite[orderSprite][0] - posX) < 2 and abs(sprite[orderSprite][1] - posY) < 2:
                        health = health - 5
                        DISPLAYSURF.fill((255,0,0,0.5))
                        p1.play()
                        cooldown = 60
                if sprite[orderSprite][3] > 0 and abs(sprite[orderSprite][0] - posX) < 1 and abs(sprite[orderSprite][1] - posY) < 1 and sprite[orderSprite][2] == texture[13]:
                    if health <= 8:
                        health = health + 2
                    sprite[orderSprite][3] = 0
                orderSprite = orderSprite + 1
                

        #detect end based on map square
        if map[int(posX)][int(posY)] == -1:
            spawnX = posX
            spawnY = posY
        if map[int(posX)][int(posY)] == -2:
            kill = 1
            orderSprite = 0
            while orderSprite <= spriteNum:
                if sprite[orderSprite][3] > 0 and sprite[orderSprite][6] >= 15:
                    kill = 0
                orderSprite = orderSprite + 1
            if kill == 1 or tutorial == 1:
                DISPLAYSURF.fill(BLACK)
                font = pygame.font.SysFont("simhei", 72)
                text = font.render("Level Complete", True, (100, 20, 20))
                DISPLAYSURF.blit(text,(30,30))
                pygame.display.update()
                l1.play()
                time.sleep(1)
                b1.stop()
                b2.stop()
                b3.stop()
                b4.stop()
                b5.stop()
                b6.stop()
                DISPLAYSURF.fill(BLACK)
                font = pygame.font.SysFont("simhei", 72)
                text = font.render("Level " + str(currentMap - 1), True, (100, 20, 20))
                DISPLAYSURF.blit(text,(30,30))
                font = pygame.font.SysFont("simhei", 20)
                text = font.render("Loading...", True, (60, 10, 10))
                DISPLAYSURF.blit(text,(40,100))
                pygame.display.update()
                time.sleep(levelLoad)
                currentMap = currentMap + 1
                breakL = 2
                tutorial = 0
            else:
                font = pygame.font.SysFont("simhei", 40)
                text = font.render("You didn't kill all enemies!", True, (100, 20, 20))
                DISPLAYSURF.blit(text,(100,50))
                pygame.display.update()

        #game end
        if currentMap >= 11:
            DISPLAYSURF.fill(BLACK)
            font = pygame.font.SysFont("simhei", 72)
            text = font.render("Game Complete", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(30,30))
            pygame.display.update()
            l1.play()
            time.sleep(2)
            b1.stop()
            b2.stop()
            b3.stop()
            b4.stop()
            b5.stop()
            b6.stop()
            DISPLAYSURF.fill(BLACK)
            font = pygame.font.SysFont("simhei", 100)
            text = font.render(("THE END"), True, (100, 20, 20))
            DISPLAYSURF.blit(text,(30,30))
            pygame.display.update()
            time.sleep(5)
            pygame.quit()
            pygame.mixer.music.stop()

        #gui
        if cooldown > 0:
            cooldown = cooldown - 1
        if tutorial != 1:
            if health == 10:
                DISPLAYSURF.blit(healthg[10],(0,0))
            if health == 9:
                DISPLAYSURF.blit(healthg[9],(0,0))
            if health == 8:
                DISPLAYSURF.blit(healthg[8],(0,0))
            if health == 7:
                DISPLAYSURF.blit(healthg[7],(0,0))
            if health == 6:
                DISPLAYSURF.blit(healthg[6],(0,0))
            if health == 5:
                DISPLAYSURF.blit(healthg[5],(0,0))
            if health == 4:
                DISPLAYSURF.blit(healthg[4],(0,0))
            if health == 3:
                DISPLAYSURF.blit(healthg[3],(0,0))
            if health == 2:
                DISPLAYSURF.blit(healthg[2],(0,0))
            if health == 1:
                DISPLAYSURF.blit(healthg[1],(0,0))
            if health == 0:
                DISPLAYSURF.blit(healthg[0],(0,0))
                font = pygame.font.SysFont("simhei", 72)
                text = font.render("You Died!", True, (100, 20, 20))
                DISPLAYSURF.blit(text,(30,30))
                pygame.display.update()
                time.sleep(3)
                b1.stop()
                b2.stop()
                b3.stop()
                b4.stop()
                b5.stop()
                b6.stop()
                breakL = 2
            

        #text
        if map[int(posX)][int(posY)] == -1 and tutorial == 1:
            font = pygame.font.SysFont("simhei", 40)
            text = font.render("These blue blocks set your spawn", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(100,50))
        if map[int(posX)][int(posY)] == -5 and tutorial == 1:
            font = pygame.font.SysFont("simhei", 40)
            text = font.render("Zombies attack by punching you.", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(100,50))
            font = pygame.font.SysFont("simhei", 40)
            text = font.render("Left click to punch back.", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(120,90))
        if map[int(posX)][int(posY)] == -3 and tutorial == 1:
            font = pygame.font.SysFont("simhei", 40)
            text = font.render("Steak heals 2 health points", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(100,50))
            font = pygame.font.SysFont("simhei", 40)
            text = font.render("Walk next to it to eat.", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(120,90))
        if map[int(posX)][int(posY)] == -4 and tutorial == 1:
            font = pygame.font.SysFont("simhei", 40)
            text = font.render("Creepers explode when next to you.", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(100,50))
            font = pygame.font.SysFont("simhei", 40)
            text = font.render("Run when you hear the fuse.", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(120,90))
        if map[int(posX)][int(posY)] == -6 and tutorial == 1:
            font = pygame.font.SysFont("simhei", 40)
            text = font.render("These red rooms end the level", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(100,50))
            font = pygame.font.SysFont("simhei", 40)
            text = font.render("Walk inside to advance the game.", True, (100, 20, 20))
            DISPLAYSURF.blit(text,(120,90))

##        font = pygame.font.SysFont("simhei", 30)
##        text = font.render(str(posX) + " " + str(posY), True, (100, 20, 20))
##        DISPLAYSURF.blit(text,(10,10))

        #update
        pygame.display.update()
        mainClock.tick(FPS)

        
#Code outside of loop
time.sleep(2)
pygame.quit()
pygame.mixer.music.stop()

